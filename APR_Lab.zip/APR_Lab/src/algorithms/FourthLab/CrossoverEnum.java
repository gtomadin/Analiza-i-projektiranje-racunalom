package algorithms.FourthLab;

public enum CrossoverEnum {
	ARITHMETIC, HEURISTIC
}
