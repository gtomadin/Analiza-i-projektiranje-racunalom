package algorithms.FourthLab;

public enum MutationEnum {
	UNIFORM, GAUSSIAN
}
