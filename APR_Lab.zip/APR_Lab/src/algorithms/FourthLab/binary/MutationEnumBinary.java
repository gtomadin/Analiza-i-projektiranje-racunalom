package algorithms.FourthLab.binary;


public enum MutationEnumBinary {
	SIMPLE, UNIFORM
}
