package algorithms.FourthLab.binary;

public enum CrossoverEnumBinary {
	UNIFORM, SINGLEPOINT
}
